import java.awt.*;
import javax.imageio.ImageIO;
import javax.swing.ImageIcon;
import javax.swing.JLabel;
import java.io.File;
import java.io.IOException;

/**
 * An abstract figure composed of a pacman image
 *
 * @author Nassim Hmamouche
 */
public class Pacman extends ImageFigure{
    /**
     * Initialize the figure properties
     *
     */
    public Pacman(int posX, int posY){
        super(30, 30, posX, posY, "assets\\pacman.png");
    }
}
