import java.awt.*;
import javax.imageio.ImageIO;
import java.io.File;
import java.io.IOException;

/**
 * An abstract figure composed of a ghost image
 *
 * @author Nassim Hmamouche
 */
public class Fantome extends ImageFigure{
    private final static String[] tabColor = new String[]{"assets\\fantomeRose.png", "assets\\fantomeRouge.png", "assets\\fantomeBleu.png", "assets\\fantomeOrange.png"}; // les 4 apparences de fantôme possibles
    
    /**
     * Initialize the figure properties
     *
     */
    public Fantome(int posX, int posY, int i){
        super(30, 30, posX, posY, tabColor[i]);
    }
}
