import java.awt.Color;

public class Fruit extends Rectangle {
    private String type;
    private int[] position;

    public Fruit(int posX, int posY){
        super(7, 7, posX, posY, Color.yellow);
        position = new int[]{posX, posY};
        type = "Cerise";
    }

    public String getType(){
        return type;
    }
    public String getPosition(){
        return position[0] + ";" + position[1];
    }
}
