import java.awt.*;
import java.util.ArrayList;

/**
 * Create shapes and display them
 *
 * @author Nassim Hmamouche
 */
public class SimplePicture {
    private Grille grille;
    private Pacman pacman;
    private ArrayList<Fantome> listeFantomes;

    /**
     * Create a new picture with a sun, a person and a house.
     */
    public SimplePicture(){
        grille = new Grille(10); //TODO nombre de cases déterminé par data
        pacman = new Pacman(250, 250);
        listeFantomes = new ArrayList<Fantome>();
        listeFantomes.add(new Fantome(200, 200, 0)); // fantôme rose
        listeFantomes.add(new Fantome(300, 200, 1)); // fantôme rouge
        listeFantomes.add(new Fantome(200, 300, 2)); // fantôme bleu
        listeFantomes.add(new Fantome(300, 300, 3)); // fantôme orange
    }

    /**
     * Main method : creates a picture, displays walls and characters and animates them
     */
    public static void main(String args[]){
        SimplePicture jeu = new SimplePicture();
        jeu.draw();
        jeu.animate();
    }

    /** 
     * Draws all the shapes
     */
    public void draw(){
        grille.draw();
        pacman.draw();
        for(Fantome fantome : listeFantomes){
            fantome.draw();
        }
    }
    
    /**
     * Animates all the shapes
     */
    public void animate(){
        while(true){
            for(Fantome fantome : listeFantomes){
                fantome.draw();
            }
            CanvasFrame.getCanvas().redraw();
            CanvasFrame.getCanvas().wait(50); // waits 50ms to refresh the display
        }
    }
}