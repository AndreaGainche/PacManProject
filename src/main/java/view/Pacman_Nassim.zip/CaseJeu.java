import java.awt.Color;

public class CaseJeu extends Rectangle {
    private static final Color[] tableColor = new Color[]{Color.blue, Color.black};
    private boolean mur;
    private Fruit fruit;
    private static int size = 50;

    public CaseJeu(int x, int y, int i){
        super(size, size, x, y, tableColor[i]);
        if(i == 0){
            mur=true;
        }
        else{
            mur=false;
            fruit = new Fruit(x+size/2, y);
        }
    }

    public Fruit getFruit(){
        return fruit;
    }
}