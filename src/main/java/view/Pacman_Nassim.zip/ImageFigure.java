import java.awt.*;
import javax.imageio.ImageIO;
import java.io.File;
import java.io.IOException;

/**
 * An abstract figure composed of an image
 *
 * @author Nassim Hmamouche
 */
public class ImageFigure extends Rectangle{
    /**
     * the shape image
     */
    private Image image;
    private final static Color transparent = new Color(0, 0, 0, 0);

    /**
     * Initialize the figure properties
     *
     */
    public ImageFigure(int width, int height, int posX, int posY, String directoryImage){
        super(width, height, posX, posY, transparent);
        try{ 
            File fileImage = new File(directoryImage);
            System.out.println(fileImage.getAbsolutePath()); // debugs
            System.out.println(fileImage.getCanonicalPath()); // debugs
            System.out.println(fileImage.getPath()); // debugs
            image = ImageIO.read(fileImage);
        }catch(IOException e){ // gestion d'exceptions : mauvaise lecture du fichier
            e.printStackTrace();
        }
    }

    /**
     * GETTER : Returns the image
     * 
     * @return Image the image
     */
    public Image getImage(){
        return this.image;
    }
}
