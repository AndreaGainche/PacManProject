import java.awt.Color;

/**
 * Creates a superFruit shape with a rectangle
 *
 * @author Nassim Hmamouche
 */
public class Fruit extends Rectangle{
    private int[] position;

    /**
     * Creates an instance of fruit
     * 
     * @param posX position on X-axis
     * @param posY position on Y-axis
     */
    public Fruit(logic.Fruit fruit){
        super(7, 7, fruit.positionIni()[0], fruit.positionIni()[1], Color.yellow);
        position = fruit.positionIni();
    }

    /**
     * Returns the position
     * 
     * @return int array containing X-position and Y-position
     */
    public int[] getPosition(){
        return new int[]{position[0], position[1]};
    }
}
