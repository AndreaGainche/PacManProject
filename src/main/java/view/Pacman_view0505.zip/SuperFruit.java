import java.io.File;
import java.util.Map;

/**
 * Create a superFruit shape with an image
 *
 * @author Nassim Hmamouche
 */
public class SuperFruit extends ImageFigure{
    private static final Map<String, String> tabColor = Map.of("Cerise", "assets"+File.separator+"cerise.png",
                                                                "Fraise", "assets"+File.separator+"fraise.png",
                                                                "Banane", "assets"+File.separator+"banane.png",
                                                                "Pomme", "assets"+File.separator+"pomme.png",
                                                                "Orange", "assets"+File.separator+"orange.png",
                                                                "Melon", "assets"+File.separator+"melon.png"); // les 6 apparences de fruits possibles   
    private String type;
    private int[] position;

    /**
     * Constructs a SuperFruit
     * 
     * @param posX position on X-axis
     * @param posY position on Y-axis
     * @param type name of the fruit
     */
    public SuperFruit(logic.Fruit fruit){
        super(25, 25, fruit.positionIni()[0], fruit.positionIni()[1], tabColor.get(fruit.gettype()));
        position = fruit.positionIni();
        this.type = fruit.gettype();
    }

    /**
     * Returns the name of the fruit
     * 
     * @return fruit name
     */
    public String getType(){
        return type;
    }
    /**
     * Returns the position of the fruit
     * 
     * @return array of 2 int (X-position, Y-position)
     */
    public String getPosition(){
        return position[0] + ";" + position[1];
    }
}
