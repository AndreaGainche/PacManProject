import java.awt.*;
import java.awt.event.KeyEvent;
import java.util.ArrayList;
import java.io.File;

/**
 * Create shapes and display them
 *
 * @author Nassim Hmamouche
 */
public class PacmanPicture {
    private Grille grille;
    private Pacman pacman;
    private ImageFigure logo;
    private ArrayList<Fantome> listeFantomes;
    private ArrayList<SuperFruit> listeFruit;

    /**
     * Create a new picture with a sun, a person and a house.
     */
    public PacmanPicture(){
        logo = new ImageFigure(150, 28, 175, 520, "assets"+File.separator+"logo.png");

        grille = new Grille(10, 10);//grille.nombreDeMur());
        pacman = new Pacman(265, 65);//(pacman.positionDepart()[0], pacman.positionDepart()[1]);

        listeFantomes = new ArrayList<Fantome>();
        listeFantomes.add(new Fantome(165, 165, 0)); // fantôme rose
        listeFantomes.add(new Fantome(165, 265, 1)); // fantôme rouge
        listeFantomes.add(new Fantome(265, 165, 2)); // fantôme bleu-
        listeFantomes.add(new Fantome(265, 265, 3)); // fantôme orange

        listeFruit = new ArrayList<SuperFruit>();
        listeFruit.add(new SuperFruit(65, 115, 0, "Cerise"));
        listeFruit.add(new SuperFruit(65, 265, 1, "Fraise"));
        listeFruit.add(new SuperFruit(65, 415, 2, "Banane"));
        listeFruit.add(new SuperFruit(465, 115, 3, "Pomme"));
        listeFruit.add(new SuperFruit(465, 265, 4, "Orange"));
        listeFruit.add(new SuperFruit(465, 415, 5, "Melon"));
    }

    /**
     * Main method : creates a picture, displays walls and characters and animates them
     */
    public static void main(String args[]){
        PacmanPicture jeu = new PacmanPicture();
        jeu.draw();
        jeu.animate();
    }

    /** 
     * Draws all the shapes
     */
    public void draw(){
        grille.draw();
        pacman.draw();
        logo.draw();
        for(Fantome fantome : listeFantomes){
            fantome.draw();
        }
        for(SuperFruit fruit : listeFruit){
            fruit.draw();
        }
    }
    
    /**
     * Animates all the shapes
     */
    public void animate(){
        while(true){
            for(Fantome fantome : listeFantomes){
                fantome.draw();
            }
            CanvasFrame.getCanvas().redraw();
            CanvasFrame.getCanvas().wait(50); // waits 50ms to refresh the display
            
            /*if(CanvasFrame.getCanvas().isUpPressed()){
                logic.grille.actualisation(grille, 1);
            }
            
            if(CanvasFrame.getCanvas().isRightPressed()){
                logic.grille.actualisation(grille, 2);
            }

            if(CanvasFrame.getCanvas().isLeftPressed()){
                logic.grille.actualisation(grille, 3);
            }

            if(CanvasFrame.getCanvas().isDownPressed()){
                logic.grille.actualisation(grille, 3);
            }*/
        }
    }
}