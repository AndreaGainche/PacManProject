import java.awt.Color;

public class Mur extends Rectangle {
    private static int size = 50;

    public Mur(logic.Mur mur){
        super(size, size, mur.getPosition()[0], mur.getPosition()[1], Color.blue);
    }
}