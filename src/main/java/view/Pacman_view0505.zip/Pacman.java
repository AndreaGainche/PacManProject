import java.io.File;

/**
 * An abstract figure composed of a pacman image
 *
 * @author Nassim Hmamouche
 */
public class Pacman extends ImageFigure{
    /**
     * Initialize the figure properties
     *
     */
    public Pacman(logic.Personnagelogic pacman){
        super(25, 25, pacman.position()[0], pacman.position()[1], "assets"+File.separator+"pacman.gif"); // séparateur de fichier différant selon l'OS (/ sur Linux, \ sur Windows)
    }
}
