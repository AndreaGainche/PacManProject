import java.util.ArrayList;
import java.awt.*;

/**
 * Create shapes and display them
 *
 * @author Nassim Hmamouche
 */
public class Grille {
    private CaseJeu[][] tabCases;

    /**
     * Create a new picture with a sun, a person and a house.
     */
    public Grille(int nbCasesX, int nbCasesY){
        tabCases = new CaseJeu[nbCasesX][nbCasesY];

        for(int i = 0; i<tabCases.length; i++){
            for(int j = 0; j<tabCases.length; j++){
                tabCases[i][j] = new CaseJeu(i*50, j*50, i%2);
            }
        }
    }

    /** 
     * Draws all the shapes
     */
    public void draw(){
        for(int i = 0; i<tabCases.length; i++){
            for(int j = 0; j<tabCases.length; j++){
                tabCases[i][j].draw();

                if(tabCases[i][j].getFruit()!=null){
                    tabCases[i][j].getFruit().draw();
                }
            }
        }
    }
}