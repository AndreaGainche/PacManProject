import java.awt.Color;

/**
 * Creates a cell with a rectangle
 *
 * @author Nassim Hmamouche
 */
public class CaseJeu extends Rectangle {
    private static final Color[] tableColor = new Color[]{Color.blue, Color.black};
    private boolean mur;
    private Fruit fruit;
    private static int size = 50;

    /**
     * Creates an instance of cell
     * 
     * @param x position on X-axis
     * @param y position on Y-axis
     * @param i color (blue or black)
     */
    public CaseJeu(int x, int y, int i){
        super(size, size, x, y, tableColor[i]);
        if(i == 0){
            mur=true;
        }
        else{
            mur=false;
            fruit = new Fruit(x+size/2, y+size/2);
        }
    }

    /**
     * Returns the fruit which the current object contains, null if there is no fruit.
     * 
     * @return the fruit which the current object contains
     */
    public Fruit getFruit(){
        return fruit;
    }
}