import java.awt.Color;

public class Mur extends Rectangle {
    private static int size = 50;

    public Mur(int x, int y, int i){
        super(size, size, x, y, Color.blue);
    }
}