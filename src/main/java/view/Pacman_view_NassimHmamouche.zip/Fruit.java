import java.awt.Color;

/**
 * Creates a superFruit shape with a rectangle
 *
 * @author Nassim Hmamouche
 */
public class Fruit extends Rectangle {
    private int[] position;

    /**
     * Creates an instance of fruit
     * 
     * @param posX position on X-axis
     * @param posY position on Y-axis
     */
    public Fruit(int posX, int posY){
        super(7, 7, posX, posY, Color.yellow);
        position = new int[]{posX, posY};
    }

    /**
     * Returns the position
     * 
     * @return int array containing X-position and Y-position
     */
    public String getPosition(){
        return position[0] + ";" + position[1];
    }
}
