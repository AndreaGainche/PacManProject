import java.io.File;

/**
 * Create a superFruit shape with an image
 *
 * @author Nassim Hmamouche
 */
public class SuperFruit extends ImageFigure {
    private final static String[] tabColor = new String[]{"assets"+File.separator+"cerise.png",
                                                          "assets"+File.separator+"fraise.png",
                                                          "assets"+File.separator+"banane.png",
                                                          "assets"+File.separator+"pomme.png",
                                                          "assets"+File.separator+"orange.png",
                                                          "assets"+File.separator+"melon.png",}; // les 6 apparences de fruits possibles    
    
    private String type;
    private int[] position;

    /**
     * Constructs a SuperFruit
     * 
     * @param posX position on X-axis
     * @param posY position on Y-axis
     * @param i number of the associated fruit image
     * @param type name of the fruit
     */
    public SuperFruit(int posX, int posY, int i, String type){
        super(25, 25, posX, posY, tabColor[i]);
        position = new int[]{posX, posY};
        this.type = type;
    }

    /**
     * Returns the name of the fruit
     * 
     * @return fruit name
     */
    public String getType(){
        return type;
    }
    /**
     * Returns the position of the fruit
     * 
     * @return array of 2 int (X-position, Y-position)
     */
    public String getPosition(){
        return position[0] + ";" + position[1];
    }
}
