import java.awt.*;
import javax.imageio.ImageIO;
import java.io.File;
import java.io.IOException;

/**
 * An abstract figure composed of a ghost image
 *
 * @author Nassim Hmamouche
 */
public class Fantome extends ImageFigure{
    private final static String[] tabColor = new String[]{"assets"+File.separator+"fantomeRose.png", "assets"+File.separator+"fantomeRouge.png", "assets"+File.separator+"fantomeBleu.png", "assets"+File.separator+"fantomeOrange.png"}; // les 4 apparences de fantôme possibles
    
    /**
     * Initialize the figure properties
     *
     */
    public Fantome(int posX, int posY, int i){
        super(25, 25, posX, posY, tabColor[i]);
    }
}
